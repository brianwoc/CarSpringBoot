package pl.altkom.car.model.Enums;

public enum Color {
    WHITE,
    BLACK,
    RED,
    GREEN,
    BLUE,
    SILVER
}
